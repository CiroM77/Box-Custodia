package com.springboot.cirom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiromApplicationTests {

	@Test
	void contextLoads() {
	}

}
